package Raneem_code.precejoral;

public class RunTimeError {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5};
        int sum = 0;

        for (int i = 0; i <= numbers.length; i++) {
            System.out.println("Loop iteration: " + i);
            
            // Debugging print statements
            System.out.println("Sum before addition: " + sum);
            System.out.println("Current number: " + numbers[i]);

            sum += numbers[i];

            // Debugging print statement
            System.out.println("Sum after addition: " + sum);
        }

        System.out.println("Total sum: " + sum);
    }
}
