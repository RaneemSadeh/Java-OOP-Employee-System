package Raneem_code.precejoral;
import java.util.Scanner;
public class GameCompanyProcedural 
{

	public static void main(String[] args){
		
		Scanner input = new Scanner(System.in);  //using the Scanner class to let the user enter the value of the variable
		
		int age ;
        String name ;
        String work ;
        String ssn;
		
        System.out.println("Enter your name : "); 
        name = input.nextLine(); // get the value of the name from the user
        System.out.println("Enter your age : ");
        age = input.nextInt(); // get the value of the age from the user
        System.out.println("Enter your ssn : ");
        ssn = input.nextLine(); // get the value of the ssn from the user
        
        System.out.println("Choose what is your work  A) Man    B) Dev: ");
        work = input.nextLine(); // get the value of the work from the user
        
        System.out.println(isManager(work)); // print the function
        System.out.print("your name is : "+name+"your age is : "+age+"your ssn is : "+ssn); // print the values
	}
		
	private static boolean isManager(String hisWork) {
		if(hisWork == "man") { // to check if he/she is a manager
			System.out.println("You are working as a Manager and you will receive 3000 JD every month");
			return true;
		} else if(hisWork == "dev"){ // to check if he/she is a developer
			System.out.println("You are working as a dev and you will receive 3000 JD every month");
			return false;
		}else { // when the input isnt correct
			System.out.println("your input isnt correct please chose from (man) or (dev)");
			return false;
		}

	}
    	
}