package Raneem_code.Oop;

public class Main {
    public static void main(String[] args) {
        Manager man=new Manager(); // created an object from the manager class using the defult constractor
	    Manager man2 = new Manager(23, "mohammad", 2, 4); // created an object from the manager class using the not defult constractor, and giving the man2 his values
	    man.sayHallo(); // to use the method in the man class for saying hello 
	    man2.setAge(22); // to make the age of the man2 equal to 22
	    System.out.println(man2.getLayer()); // to print the value of the layer for man2
	    Developer dev = new Developer(); // created an object from the developer class using the defult constractor
	    dev.sayHallo(); // to use the method in the dev class for saying hello
        dev.setName("rashed");
        System.out.println(dev.getName());
    }
}
