package Raneem_code.Oop;

public class Manager extends emp{
    private int layer;
    private int manExperiance;

    public Manager(){ // defult constractor
        System.out.println("new manager into the team");
    }

    public Manager(int age, String name, int layer, int manExperiance){ // not defult constractor
        super(age, name); // to use the attributes for the extended class
        this.layer=layer;
        this.manExperiance=manExperiance;
        System.out.println("new manager into the team");
    }

    public void setLayer(int layer) { // to set the layer value
        this.layer = layer;
    }

    public int getLayer() { // to get the layer value
        return layer;
    }

    public void setManExperiance(int manExperiance) { // to set the experiance value
        this.manExperiance = manExperiance;
    }

    public int getManExperiance() { // to get the experiance value
        return manExperiance;
    }

    public void sayHallo(){ // a method to say hello to the manager
        System.out.println("Hello from the manager");
    }
}
