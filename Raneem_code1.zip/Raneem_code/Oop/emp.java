package Raneem_code.Oop;

public class emp {
    private int age;
    private String name;

    public emp(){ // defult constractor 

    }

    public emp(int age, String name){ // not defult constractor
        this.age=age;
        this.name=name;
    }

    public void setAge(int age) { // set the age value
        this.age = age;
    }

    public int getAge() {// get the age value
        return age;
    }

    public void setName(String name) {// set the name value
        this.name = name;
    }

    public String getName() {// get the name value
        return name;
    }

    public void sayHello(){ // say hello method
        System.out.println("Hello");
    }
}
