package Raneem_code.Oop;

public class Developer extends emp{
    private String framework;
    private int devExperiance;

    public Developer(){ // defult constractor
        System.out.println("new developer into the team!!");
    }

    public Developer(String name, int age, int devExperiance, String framework){ // not defult constractor
        super(age, name); // to use the attributes for the extended class 
        this.devExperiance=devExperiance;
        this.framework=framework;
        System.out.println("new developer into the team!!");
    }

    public void setFramework(String framework) { // set the value for the framework the dev using
        this.framework = framework;
    }

    public String getFramework() { // get the value for the framework the dev using
        return framework;
    }

    public void setDevExperiance(int devExperiance) { // set the value for the year of experiance
        this.devExperiance = devExperiance;
    }

    public int getDevExperiance() { // get the value for the year of experiance
        return devExperiance;
    }

    public void sayHallo(){ // say hello to the developer
        System.out.println("Hello from the developer");
    }
}
